#ifndef COLLEGE_MANAGEMENT_C
#define COLLEGE_MANAGEMENT_C

void addCollegeDetails();
void collegeLogin();
void displayCollegeDetails();

void addCollegeDetails() {
    College *newCollege = (College *)malloc(sizeof(College));
    if (!newCollege) {
        printf("Memory allocation failed!\n");
        return;
    }

    printf("Enter College Code:\n");
    scanf("%s", newCollege->collegeCode);

    printf("Enter College Name:\n");
    scanf("%s", newCollege->collegeName);

    newCollege->studentCount  = 0;
    newCollege->studentList   = NULL;
    newCollege->nextCollege   = NULL;


    if (!board.collegeList)
        board.collegeList = newCollege;
    else {
        College *temp = board.collegeList;
        while (temp->nextCollege)
            temp = temp->nextCollege;
        temp->nextCollege = newCollege;
    }
}

void displayCollegeDetails() {
    College *temp = board.collegeList;
    if (!temp) {
        printf("\nNo Colleges Available.\n");
        return;
    }

    printf("\n--- College List ---\n");
    while (temp) {
        printf("College Code : %s\n", temp->collegeCode);
        printf("College Name : %s\n", temp->collegeName);
        printf("Total Students: %d\n", temp->studentCount);
        printf("-------------------------\n");
        temp = temp->nextCollege;
    }
}

void collegeLogin()
{
    char enteredCollegeCode[10];
    printf("\n--- College Login ---\n");
    printf("Enter College Code: ");
    scanf("%9s", enteredCollegeCode);

    int found = 0;
    College *current = board.collegeList;

    while (current != NULL) {
        if (strcmp(enteredCollegeCode, current->collegeCode) == 0) {
            printf("\nLogin successful for College: %s\n", current->collegeName);
            found = 1;

            int choice;
            do {
                printf("\n--- College Menu ---\n");
                printf("1. Add Student Details\n");
                printf("2. Display Student Details\n");
                printf("3. Logout\n");
                printf("Enter your choice: ");
                scanf("%d", &choice);

                switch (choice) {
                case 1:
                    addStudentDetails();
                    printf("Student Details Added Successfully\n");
                    break;
                case 2:
                    displayStudentDetails();
                    break;
                case 3:
                    printf("Logging out...\n");
                    break;
                default:
                    printf("Invalid choice. Please try again.\n");
                }
            } while (choice != 3);

            break;
        }
        current = current->nextCollege;
    }

    if (!found) {
        printf("Invalid College Code.\n");
    }
}



#endif // COLLEGE_MANAGEMENT_C
