TEMPLATE = app
CONFIG += console
CONFIG -= app_bundle
CONFIG -= qt

SOURCES += \
        board_management.c \
        college_management.c \
        main.c \
        marks_management.c \
        menu.c \
        student_details.c \
        student_management.c

HEADERS += \
    College.h \
    DateOfBirth.h \
    Evaluator.h \
    Exam.h \
    Marks.h \
    MarksDetails.h \
    PUBoard.h \
    Stream.h \
    Student.h \
    StudentAcademicDetails.h \
    StudentPersonalDetails.h \
    Subject.h
