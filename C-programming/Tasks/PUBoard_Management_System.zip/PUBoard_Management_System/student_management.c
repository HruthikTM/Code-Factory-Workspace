#ifndef STUDENT_MANAGEMENT_C
#define STUDENT_MANAGEMENT_C

void addStudentDetails();
void studentLogin();
void displayStudentDetails();

void addStudentDetails() {
    if (!board.collegeList) {
        printf("Please enter college details first.\n");
        return;
    }

    char collegeCode[10];
    printf("Enter the College Code to add the student to:\n");
    scanf("%s", collegeCode);

    College *targetCollege = board.collegeList;
    while (targetCollege && strcmp(targetCollege->collegeCode, collegeCode) != 0)
        targetCollege = targetCollege->nextCollege;

    if (!targetCollege) {
        printf("College with code %s not found.\n", collegeCode);
        return;
    }

    Student *newStudent = (Student *)malloc(sizeof(Student));
    if (!newStudent) {
        printf("Memory allocation failed for Student\n");
        return;
    }

    printf("Enter Student ID:\n");
    scanf("%s", newStudent->studentId);

    newStudent->spd = (StudentPersonalDetails *)enterStudentPersonalDetails();
    newStudent->sad = (StudentAcademicDetails *)enterStudentAcademicDetails();
    newStudent->nextStudent = NULL;


    if (!targetCollege->studentList)
        targetCollege->studentList = newStudent;
    else {
        Student *temp = targetCollege->studentList;
        while (temp->nextStudent) temp = temp->nextStudent;
        temp->nextStudent = newStudent;
    }

    targetCollege->studentCount++;
    printf("Student added successfully to %s (%s).\n", targetCollege->collegeName, targetCollege->collegeCode);
}

void displayStudentDetails() {
    College *college = board.collegeList;
    if (!college) {
        printf("No college found.\n");
        return;
    }

    while (college) {
        Student *student = college->studentList;
        if (!student)
            printf("No students found for the college: %s\n", college->collegeName);
        else {
            printf("\n--- Student List for College %s ---\n", college->collegeName);
            while (student) {
                printf("Student ID: %s\n", student->studentId);
                displayStudentPersonalDetails(student->spd);
                displayStudentAcademicDetails(student->sad);
                printf("-------------------------\n");
                student = student->nextStudent;
            }
        }
        college = college->nextCollege;
    }
}

void studentLogin()
{
    char enteredStudentID[10];
    printf("\n--- Student Login ---\n");
    printf("Enter Student ID: ");
    scanf("%9s", enteredStudentID);

    int found = 0;
    Student *current = board.collegeList->studentList;

    while (current != NULL) {
        if (strcmp(enteredStudentID, current->studentId) == 0) {
            printf("\nLogin successful for Name: %s\n", current->spd->studentName);
            found = 1;

            int choice;
            do {
                printf("\n--- Student Menu ---\n");
                printf("1. Get Result\n");
                printf("2. Logout\n");
                printf("Enter your choice: ");
                scanf("%d", &choice);

                switch (choice) {
                case 1:
                    getIndividualStudentResult();
                    printf("Student Details Added Successfully\n");
                    break;
                case 2:
                    printf("Logging out...\n");
                    break;
                default:
                    printf("Invalid choice. Please try again.\n");
                }
            } while (choice != 2);

            break;
        }
        current = current->nextStudent;
    }

    if (!found) {
        printf("Invalid College ID.\n");
    }
}

#endif // STUDENT_MANAGEMENT_C
