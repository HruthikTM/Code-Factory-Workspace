#ifndef BOARD_MANAGEMENT_C
#define BOARD_MANAGEMENT_C

void addBoardDetails();
void boardLogin();


void addBoardDetails() {
    if (boardCount >= MAX_BOARDS) {
        printf("Maximum number of boards reached.\n");
        return;
    }

    printf("\n--- Add Board Details ---\n");
    printf("Enter Board Name: ");
    scanf("%s", boards[boardCount].boardName);
    printf("Set User ID: ");
    scanf("%s", boards[boardCount].userId);
    printf("Set Password: ");
    scanf("%s", boards[boardCount].password);

    boardCount++;
    printf("Board details added successfully.\n");
}


void boardLogin() {
    char enteredUserId[20];
    char enteredPassword[20];

    printf("\n--- Board Login ---\n");
    printf("Enter User ID: ");
    scanf("%s", enteredUserId);
    printf("Enter Password: ");
    scanf("%s", enteredPassword);

    int found = 0;

    for (int i = 0; i < boardCount; i++) {
        if (strcmp(enteredUserId, boards[i].userId) == 0 && strcmp(enteredPassword, boards[i].password) == 0) {
            printf("\nLogin successful for Board: %s\n", boards[i].boardName);
            found = 1;

            int choice;
            do {
                printf("\n--- Board Menu ---\n");
                printf("1. Add College Details\n");
                printf("2. Display College Details\n");
                printf("3. Display College-wise Pass Percentage\n");
                printf("4. Logout\n");
                printf("Enter your choice: ");
                scanf("%d", &choice);

                switch (choice) {
                case 1:
                    addCollegeDetails();
                    printf("College Details Added Successfully\n");
                    break;
                case 2:
                    displayCollegeDetails();
                    break;
                case 3:
                    displayCollegeWisePassPercentage();
                    break;
                case 4:
                    printf("Logging out...\n");
                    break;
                default:
                    printf("Invalid choice. Please try again.\n");
                }
            }
            while (choice != 3);

            break;
        }
    }

    if (!found) {
        printf("Invalid User ID or Password.\n");
    }
}

#endif // BOARD_MANAGEMENT_C
