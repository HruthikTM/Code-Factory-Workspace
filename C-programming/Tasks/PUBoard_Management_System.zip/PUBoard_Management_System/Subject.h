#ifndef SUBJECT_H
#define SUBJECT_H

typedef struct Subject{

    char subjectCode[10];
    char subjectName[20];

}Subject;

#endif // SUBJECT_H
