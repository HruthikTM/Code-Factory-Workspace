#ifndef EVALUATOR_H
#define EVALUATOR_H

#define MAX_EVALUATOR 12

typedef struct Evaluator{
    char userId[20];
    char password[20];
    Student *s;
    MarksDetails *md;

}Evaluator;

Evaluator evaluators[MAX_EVALUATOR];
int evaluatorCount = 0;

#endif // EVALUATOR_H
