#ifndef MARKS_H
#define MARKS_H

typedef struct Marks{

    int totalMarks;
    int obtainedMarks;

}Marks;

#endif // MARKS_H
