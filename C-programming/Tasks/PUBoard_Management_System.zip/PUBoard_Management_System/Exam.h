#ifndef EXAM_H
#define EXAM_H

#include "Subject.h"
#include "Marks.h"

typedef struct Exam{
    Subject *sub;
    Marks *marks;
}Exam;

#endif // EXAM_H
