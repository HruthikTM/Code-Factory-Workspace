#ifndef STUDENT_H
#define STUDENT_H

#include "StudentPersonalDetails.h"
#include "StudentAcademicDetails.h"

typedef struct Student{

    char studentId[10];
    struct Student *nextStudent;
    StudentPersonalDetails *spd;
    StudentAcademicDetails *sad;

}Student;


#endif // STUDENT_H
