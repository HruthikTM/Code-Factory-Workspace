#ifndef STUDENTPERSONALDETAILS_H
#define STUDENTPERSONALDETAILS_H

#include "DateOfBirth.h"

typedef struct StudentPersonalDetails{

    char studentName[20];
    char studentFatherName[20];
    char studentMotherName[20];
    char studentContactNumber[10];
    char studentAddress[30];
    DateOfBirth *dob;

}StudentPersonalDetails;

#endif // STUDENTPERSONALDETAILS_H
