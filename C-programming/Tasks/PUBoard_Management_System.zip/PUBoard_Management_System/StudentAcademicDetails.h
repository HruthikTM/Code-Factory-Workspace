#ifndef STUDENTACADEMICDETAILS_H
#define STUDENTACADEMICDETAILS_H

#include "MarksDetails.h"
#include "Stream.h"
#define SUBJECT_COUNT 4


typedef struct {
    MarksDetails *marksDetails[SUBJECT_COUNT];
    Stream *stream[3];
} StudentAcademicDetails;

#endif // STUDENTACADEMICDETAILS_H
