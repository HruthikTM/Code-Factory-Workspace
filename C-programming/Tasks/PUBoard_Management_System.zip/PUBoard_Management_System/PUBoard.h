#ifndef PUBOARD_H
#define PUBOARD_H

#define MAX_BOARDS 10

#include "College.h"
#include "Evaluator.h"

typedef struct PUBoard {
    char boardName[50];
    char userId[20];
    char password[20];
    College *collegeList;
    Evaluator *evaluator;
} PUBoard;

PUBoard boards[MAX_BOARDS];
int boardCount = 0;

#endif // PUBOARD_H









