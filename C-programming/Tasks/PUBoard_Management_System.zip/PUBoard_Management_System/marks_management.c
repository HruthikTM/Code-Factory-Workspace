#ifndef MARKS_MANAGEMENT_C
#define MARKS_MANAGEMENT_C

void evaluatorLogin();
void enterStudentMarks();
void displayCollegeWisePassPercentage();
void getIndividualStudentResult();


void evaluatorLogin() {
    char enteredUserId[20];
    char enteredPassword[20];

    printf("\n--- Evaluator Login ---\n");
    printf("Enter User ID: ");
    scanf("%s", enteredUserId);
    printf("Enter Password: ");
    scanf("%s", enteredPassword);

    int found = 0;

    for (int i = 0; i < evaluatorCount; i++) {
        if (strcmp(enteredUserId, evaluators[i].userId) == 0 && strcmp(enteredPassword, evaluators[i].password) == 0) {
            printf("\nLogin successful for Evaluator\n");
            found = 1;

            int choice;
            do {
                printf("\n--- Evaluator Menu ---\n");
                printf("1. Enter Student Marks\n");
                printf("2. Logout\n");
                printf("Enter your choice: ");
                scanf("%d", &choice);

                switch (choice) {
                case 1:
                    enterStudentMarks();
                    break;
                case 2:
                    printf("Logging out...\n");
                    break;
                default:
                    printf("Invalid choice. Please try again.\n");
                }
            }
            while (choice != 2);

            break;
        }
    }

    if (!found) {
        printf("Invalid User ID or Password.\n");
    }
}


void enterStudentMarks() {
    if (!board.collegeList) {
        printf("No colleges available.\n");
        return;
    }

    char studentId[20], subjectCode[10];
    int totalMarks, obtainedMarks;

    printf("Enter student ID: ");
    scanf("%s", studentId);
    printf("Enter subject code: ");
    scanf("%s", subjectCode);

    College *college = board.collegeList;
    Student *foundStudent = NULL;
    while (college) {
        Student *student = college->studentList;
        while (student) {
            if (strcmp(student->studentId, studentId) == 0) {
                foundStudent = student;
                break;
            }
            student = student->nextStudent;
        }
        if (foundStudent)
            break;
        college = college->nextCollege;
    }

    if (!foundStudent) {
        printf("Student with ID %s not found.\n", studentId);
        return;
    }

    StudentAcademicDetails *sad = foundStudent->sad;
    if (!sad || !sad->stream[0]) {
        printf("Academic details not found.\n");
        return;
    }

    int i;
    for (i = 0; i < SUBJECT_COUNT; ++i) {
        if (strcmp(sad->marksDetails[i]->sub->subjectCode, subjectCode) == 0)
            break;
    }

    if (i == SUBJECT_COUNT) {
        printf("Subject code %s not found.\n", subjectCode);
        return;
    }

    printf("Enter total marks for %s: ", sad->marksDetails[i]->sub->subjectName); scanf("%d", &totalMarks);
    printf("Enter obtained marks: "); scanf("%d", &obtainedMarks);

    sad->marksDetails[i]->m->totalMarks = totalMarks;
    sad->marksDetails[i]->m->obtainedMarks = obtainedMarks;
    sad->marksDetails[i]->maxScore = totalMarks;
    sad->marksDetails[i]->obtainedScore = obtainedMarks;
    sad->marksDetails[i]->percentage = (totalMarks != 0) ? ((float)obtainedMarks / totalMarks) * 100.0f : 0.0f;

    float p = sad->marksDetails[i]->percentage;
    sad->marksDetails[i]->grade = (p >= 90) ? 'A' : (p >= 75) ? 'B' : (p >= 60) ? 'C' : (p >= 40) ? 'D' : 'F';

    printf("Marks updated successfully for student %s in subject %s.\n", studentId, sad->marksDetails[i]->sub->subjectName);
}

void displayCollegeWisePassPercentage() {
    if (!board.collegeList) {
        printf("No colleges available.\n");
        return;
    }

    College *college = board.collegeList;
    printf("\n--- College-wise Pass Percentage ---\n");

    while (college) {
        int totalStudents = 0;
        int passedStudents = 0;

        Student *student = college->studentList;
        while (student) {
            totalStudents++;
            int isFail = 0;

            StudentAcademicDetails *sad = student->sad;
            if (sad && sad->stream[0]) {
                for (int i = 0; i < SUBJECT_COUNT; i++) {
                    if (sad->marksDetails[i] && sad->marksDetails[i]->grade == 'F') {
                        isFail = 1;
                        break;
                    }
                }

                if (!isFail)
                    passedStudents++;
            }

            student = student->nextStudent;
        }

        float passPercentage = (totalStudents > 0) ? ((float)passedStudents / totalStudents) * 100.0f : 0.0f;

        printf("College: %s (%s)\n", college->collegeName, college->collegeCode);
        printf("  Total Students   : %d\n", totalStudents);
        printf("  Passed Students  : %d\n", passedStudents);
        printf("  Pass Percentage  : %.2f%%\n", passPercentage);
        printf("----------------------------------------\n");

        college = college->nextCollege;
    }
}

void getIndividualStudentResult() {
    if (!board.collegeList) {
        printf("No colleges available.\n");
        return;
    }

    char studentId[20];
    int day, year;
    char month[15];

    printf("\n--- Student Result Portal ---\n");
    printf("Enter Student ID: ");
    scanf("%s", studentId);
    printf("Enter Date of Birth (DD Month YYYY): ");
    scanf("%d %s %d", &day, month, &year);

    College *college = board.collegeList;
    Student *foundStudent = NULL;

    while (college) {
        Student *student = college->studentList;
        while (student) {
            if (strcmp(student->studentId, studentId) == 0 && student->spd && student->spd->dob && student->spd->dob->date == day && strcmp(student->spd->dob->month, month) == 0 && student->spd->dob->year == year) {
                foundStudent = student;
                break;
            }
            student = student->nextStudent;
        }
        if (foundStudent)
            break;
        college = college->nextCollege;
    }

    if (!foundStudent) {
        printf("Invalid Student ID or Date of Birth.\n");
        return;
    }

    StudentAcademicDetails *sad = foundStudent->sad;
    if (!sad || !sad->stream[0]) {
        printf("Academic details not found.\n");
        return;
    }

    printf("\n----- Student Result -----\n");
    printf("Student ID     : %s\n", foundStudent->studentId);
    printf("Student Name   : %s\n", foundStudent->spd->studentName);
    printf("Father's Name  : %s\n", foundStudent->spd->studentFatherName);
    printf("Date of Birth  : %d %s %d\n", foundStudent->spd->dob->date, foundStudent->spd->dob->month, foundStudent->spd->dob->year);
    printf("\n--- Subject-wise Marks ---\n");

    int totalMarks = 0, obtainedMarks = 0;
    float overallPercentage = 0.0;
    int isFail = 0;

    for (int i = 0; i < SUBJECT_COUNT; i++) {
        MarksDetails *md = sad->marksDetails[i];
        if (!md)
            continue;

        totalMarks += md->m->totalMarks;
        obtainedMarks += md->m->obtainedMarks;

        if (md->grade == 'F')
            isFail = 1;

        printf("Subject: %s (%s)\n", md->sub->subjectName, md->sub->subjectCode);
        printf("  Marks: %d/%d\n", md->m->obtainedMarks, md->m->totalMarks);
        printf("  Grade: %c\n", md->grade);
        printf("---------------------------\n");
    }

    if (totalMarks > 0)
        overallPercentage = ((float)obtainedMarks / totalMarks) * 100.0f;

    char overallGrade = (overallPercentage >= 90) ? 'A' : (overallPercentage >= 75) ? 'B' : (overallPercentage >= 60) ? 'C' : (overallPercentage >= 40) ? 'D' : 'F';

    printf("\nTotal Marks     : %d\n", totalMarks);
    printf("Obtained Marks  : %d\n", obtainedMarks);
    printf("Percentage      : %.2f%%\n", overallPercentage);
    printf("Overall Grade   : %c\n", isFail ? 'F' : overallGrade);
    printf("---------------------------\n");
}


#endif // MARKS_MANAGEMENT_C
