#ifndef STREAM_H
#define STREAM_H

#include "Subject.h"
#define SUBJECT_COUNT 4


typedef struct {
    char streamName[20];
    Subject *subjects[SUBJECT_COUNT];
} Stream;


#endif // STREAM_H
