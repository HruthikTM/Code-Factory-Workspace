#ifndef DATEOFBIRTH_H
#define DATEOFBIRTH_H

typedef struct DateOfBirth{
    int date;
    char month[10];
    int year;

}DateOfBirth;

#endif // DATEOFBIRTH_H


