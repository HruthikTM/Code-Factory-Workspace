#include <stdio.h>

int main()
{
    puManagementMenu();
    return 0;
}
