#ifndef COLLEGE_H
#define COLLEGE_H

#include "Student.h"

typedef struct College{

    int studentCount;
    char collegeCode[10];
    char collegeName[20];
    struct College *nextCollege;
    Student *studentList;

}College;



#endif // COLLEGE_H
