#ifndef MARKSDETAILS_H
#define MARKSDETAILS_H

#include "Student.h"
#include "Marks.h"
#include "Subject.h"

typedef struct {
    Subject *sub;
    Marks   *m;
    int maxScore;
    int obtainedScore;
    float percentage;
    char grade;
} MarksDetails;


#endif // MARKSDETAILS_H
