#ifndef STUDENT_DETAILS_C
#define STUDENT_DETAILS_C

void* enterStudentPersonalDetails();
void* enterStudentAcademicDetails();
void displayStudentPersonalDetails(StudentPersonalDetails *spd);
void displayStudentAcademicDetails(StudentAcademicDetails *sad);



void* enterStudentPersonalDetails() {
    printf("\n--- Student Personal Details ---\n");

    StudentPersonalDetails *spd = (StudentPersonalDetails *)malloc(sizeof(StudentPersonalDetails));
    if (!spd) {
        printf("Memory allocation failed for StudentPersonalDetails\n");
        return NULL;
    }

    spd->dob = (DateOfBirth *)malloc(sizeof(DateOfBirth));
    if (!spd->dob) {
        printf("Memory allocation failed for DateOfBirth\n");
        free(spd);
        return NULL;
    }

    printf("Enter Student Name:\n");
    scanf("%s", spd->studentName);

    printf("Enter Father's Name:\n");
    scanf("%s", spd->studentFatherName);

    printf("Enter Mother's Name:\n");
    scanf("%s", spd->studentMotherName);

    printf("Enter Contact Number:\n");
    scanf("%s", spd->studentContactNumber);

    printf("Enter Address:\n");
    scanf("%s", spd->studentAddress);

    printf("Enter Date of Birth (DD Month YYYY):\n");
    scanf("%d %s %d", &spd->dob->date, spd->dob->month, &spd->dob->year);

    return spd;
}


void* enterStudentAcademicDetails() {
    printf("\n--- Student Academic Details ---\n");

    StudentAcademicDetails *sad = (StudentAcademicDetails *)malloc(sizeof(StudentAcademicDetails));
    if (!sad) {
        printf("Memory allocation failed\n");
        return NULL;
    }

    const char *streamNames[] = {"Science", "Commerce", "Arts"};

    const char *scienceSubjects[] = {"Physics", "Chemistry", "Mathematics", "Biology"};
    const char *scienceCodes[] = {"PHY", "CHE", "MAT", "BIO"};

    const char *commerceSubjects[] = {"Accountancy", "BusinessStudies", "Economics", "Commerce"};
    const char *commerceCodes[] = {"ACC", "BST", "ECO", "COM"};

    const char *artsSubjects[] = {"History", "PoliticalScience", "Sociology", "Psychology"};
    const char *artsCodes[] = {"HIS", "POL", "SOC", "PSY"};

    printf("Select Stream:\n1. Science\n2. Commerce\n3. Arts\n");
    int streamChoice;
    printf("Enter your Choice: ");
    scanf("%d", &streamChoice);

    Stream *selectedStream = (Stream *)malloc(sizeof(Stream));
    if (!selectedStream) {
        printf("Memory allocation failed\n");
        free(sad);
        return NULL;
    }
    strcpy(selectedStream->streamName, streamNames[streamChoice - 1]);

    for (int i = 0; i < SUBJECT_COUNT; ++i) {
        selectedStream->subjects[i] = (Subject *)malloc(sizeof(Subject));
        if (!selectedStream->subjects[i]) {
            for (int j = 0; j < i; ++j)
                free(selectedStream->subjects[j]);
            free(selectedStream);
            free(sad);
            return NULL;
        }

        switch (streamChoice) {
        case 1:
            strcpy(selectedStream->subjects[i]->subjectName, scienceSubjects[i]);
            strcpy(selectedStream->subjects[i]->subjectCode, scienceCodes[i]);
            break;
        case 2:
            strcpy(selectedStream->subjects[i]->subjectName, commerceSubjects[i]);
            strcpy(selectedStream->subjects[i]->subjectCode, commerceCodes[i]);
            break;
        case 3:
            strcpy(selectedStream->subjects[i]->subjectName, artsSubjects[i]);
            strcpy(selectedStream->subjects[i]->subjectCode, artsCodes[i]);
            break;
        default:
            strcpy(selectedStream->subjects[i]->subjectName, "Unknown");
            strcpy(selectedStream->subjects[i]->subjectCode, "UNK");
        }

        sad->marksDetails[i] = (MarksDetails *)malloc(sizeof(MarksDetails));
        sad->marksDetails[i]->sub = selectedStream->subjects[i];
        sad->marksDetails[i]->m = (Marks *)malloc(sizeof(Marks));
        sad->marksDetails[i]->m->totalMarks = 0;
        sad->marksDetails[i]->m->obtainedMarks = 0;
        sad->marksDetails[i]->maxScore = 0;
        sad->marksDetails[i]->obtainedScore = 0;
        sad->marksDetails[i]->percentage = 0.0f;
        sad->marksDetails[i]->grade = '-';
    }

    for (int i = 0; i < 3; ++i) sad->stream[i] = NULL;
    sad->stream[0] = selectedStream;

    printf("\nSubjects in %s Stream:\n", selectedStream->streamName);
    for (int i = 0; i < SUBJECT_COUNT; ++i)
        printf("  • %s (%s)\n", selectedStream->subjects[i]->subjectName, selectedStream->subjects[i]->subjectCode);

    return sad;
}

void displayStudentPersonalDetails(StudentPersonalDetails *spd) {
    if (!spd || !spd->dob) {
        printf("No personal details available.\n");
        return;
    }

    printf("\n--- Personal Details ---\n");
    printf("Name          : %s\n", spd->studentName);
    printf("Father's Name : %s\n", spd->studentFatherName);
    printf("Mother's Name : %s\n", spd->studentMotherName);
    printf("Contact Number: %s\n", spd->studentContactNumber);
    printf("Address       : %s\n", spd->studentAddress);
    printf("DOB           : %d %s %d\n", spd->dob->date, spd->dob->month, spd->dob->year);
}

void displayStudentAcademicDetails(StudentAcademicDetails *sad) {
    if (!sad || !sad->stream[0]) {
        printf("No academic details available.\n");
        return;
    }

    printf("\n--- Academic Details ---\n");
    printf("Stream: %s\n", sad->stream[0]->streamName);

    int totalMaxMarks = 0;
    int totalObtainedMarks = 0;
    int isFail = 0;

    for (int i = 0; i < SUBJECT_COUNT; ++i) {
        if (!sad->marksDetails[i])
            continue;

        totalMaxMarks += sad->marksDetails[i]->m->totalMarks;
        totalObtainedMarks += sad->marksDetails[i]->m->obtainedMarks;

        if (sad->marksDetails[i]->grade == 'F')
            isFail = 1;

        printf("Subject: %s (%s)\n", sad->marksDetails[i]->sub->subjectName, sad->marksDetails[i]->sub->subjectCode);
        printf("  Total Marks    : %d\n", sad->marksDetails[i]->m->totalMarks);
        printf("  Obtained Marks : %d\n", sad->marksDetails[i]->m->obtainedMarks);
        printf("  Percentage     : %.2f%%\n", sad->marksDetails[i]->percentage);
        printf("  Grade          : %c\n", sad->marksDetails[i]->grade);
        printf("  ---------------------------\n");
    }

    float overallPercentage = (totalMaxMarks == 0) ? 0.0f : ((float)totalObtainedMarks / totalMaxMarks) * 100.0f;

    printf(">>> Total Marks         : %d\n", totalMaxMarks);
    printf(">>> Total Obtained Marks: %d\n", totalObtainedMarks);
    printf(">>> Overall Percentage  : %.2f%%\n", overallPercentage);
    printf(">>> Final Result        : %s\n", isFail ? "Fail" : "Pass");
}

#endif // STUDENT_DETAILS_C
